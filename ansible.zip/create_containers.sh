#!/bin/bash

# Переменные
DOWNLOAD_URL="http://download.proxmox.com/images/system/ubuntu-22.04-standard_22.04-1_amd64.tar.zst"
FILENAME="ubuntu-22.04-standard_22.04-1_amd64.tar.zst"
TARGET_DIR="/var/lib/vz/template/cache"
FILE_PATH="$TARGET_DIR/$FILENAME"

# Проверяем существование директории, создаем если нет
if [ ! -d "$TARGET_DIR" ]; then
    echo "Создаем директорию: $TARGET_DIR"
    mkdir -p "$TARGET_DIR"
fi

# Проверяем существует ли файл
if [ -f "$FILE_PATH" ]; then
    echo "Файл $FILENAME уже существует в $TARGET_DIR"
    echo "Скачивание не требуется."
else
    echo "Файл $FILENAME не найден. Начинаем скачивание..."
    wget -P "$TARGET_DIR" "$DOWNLOAD_URL"
    
    # Проверяем успешность скачивания
    if [ $? -eq 0 ]; then
        echo "Скачивание успешно завершено!"
        echo "Файл сохранен: $FILE_PATH"
    else
        echo "Ошибка при скачивании файла!"
        exit 1
    fi
fi


# Конфигурация контейнеров
declare -A CONTAINERS=(
    ["100"]="ct-lb,192.168.104.90,2,1,512,256"
    ["101"]="ct-web1,192.168.104.91,5,1,1024,512" 
    ["102"]="ct-web2,192.168.104.92,5,1,1024,512"
    ["103"]="ct-db,192.168.104.93,10,2,2048,1024"
)

# Общие настройки
TEMPLATE="local:vztmpl/ubuntu-22.04-standard_22.04-1_amd64.tar.zst"
STORAGE="local-lvm"
BRIDGE="vmbr0"
NETWORK="192.168.104.0/24"
GATEWAY="192.168.104.1"
PASSWORD='P@$$w0rd'

# Функция создания контейнера
create_container() {
    local id=$1
    local hostname=$2
    local ip=$3
    local rootfs=$4
    local cores=$5
    local memory=$6
    local swap=$7

    echo "Создаем контейнер $hostname (ID: $id)"
    
    pct create $id $TEMPLATE \
        --storage $STORAGE \
        --rootfs $rootfs \
        --hostname $hostname \
        --password "$PASSWORD" \
        --cores $cores \
        --memory $memory \
        --swap $swap \
        --net0 name=eth0,bridge=$BRIDGE,ip=$ip/24,gw=$GATEWAY
    
    if [ $? -eq 0 ]; then
        echo "✓ Контейнер $hostname создан успешно"
        return 0
    else
        echo "✗ Ошибка при создании контейнера $hostname"
        return 1
    fi
}

# Функция настройки SSH
configure_ssh() {
    local id=$1
    local hostname=$2
    
    echo "Настраиваем SSH для $hostname..."
    
    # Ждем запуска контейнера
    sleep 3
    
    pct exec $id -- bash -c "
        echo 'PermitRootLogin yes' >> /etc/ssh/sshd_config
        echo 'PasswordAuthentication yes' >> /etc/ssh/sshd_config
        echo 'PubkeyAuthentication yes' >> /etc/ssh/sshd_config
        systemctl restart ssh
        systemctl enable ssh
        apt update && apt install -y curl wget net-tools
    "
    
    echo "✓ SSH настроен для $hostname"
}

# Функция запуска контейнеров
start_containers() {
    echo "Запускаем все контейнеры..."
    for id in "${!CONTAINERS[@]}"; do
        echo "Запуск CT-$id"
        pct start $id
        sleep 2
    done
    echo "✓ Все контейнеры запущены"
}

# Функция показа статуса
show_status() {
    echo ""
    echo "=== Статус контейнеров ==="
    pct list | grep -E "$(echo "${!CONTAINERS[@]}" | tr ' ' '|')"
    
    echo ""
    echo "=== IP адреса ==="
    for id in "${!CONTAINERS[@]}"; do
        IFS=',' read -r hostname ip rootfs cores memory swap <<< "${CONTAINERS[$id]}"
        echo "$hostname: $ip"
    done
}

# Основная логика
main() {
    echo "Начинаем создание контейнеров..."
    
    # Создаем контейнеры
    for id in "${!CONTAINERS[@]}"; do
        IFS=',' read -r hostname ip rootfs cores memory swap <<< "${CONTAINERS[$id]}"
        create_container "$id" "$hostname" "$ip" "$rootfs" "$cores" "$memory" "$swap"
    done
    
    # Запускаем контейнеры
    start_containers
    
    # Настраиваем SSH
    for id in "${!CONTAINERS[@]}"; do
        IFS=',' read -r hostname ip rootfs cores memory swap <<< "${CONTAINERS[$id]}"
        configure_ssh "$id" "$hostname"
    done
    
    show_status
    
    echo ""
    echo "=== Готово! ==="
    echo "Для подключения используйте:"
    for id in "${!CONTAINERS[@]}"; do
        IFS=',' read -r hostname ip rootfs cores memory swap <<< "${CONTAINERS[$id]}"
        echo "ssh root@$ip  # $hostname"
    done
}

# Запуск скрипта
main "$@"
